-- Lua uses '--' as comment to end of line read the
-- manual for more comment options.
pktgen.screen("off");

